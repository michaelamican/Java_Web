
public class BatTest {
	public static void main(String[] args) {
		Bat a = new Bat();
		
		a.attackTown();
		a.attackTown();
		a.fly();
		a.eatHumans();
		a.eatHumans();
		a.eatHumans("Jonathan Taylor Thomas");
		a.eatHumans();
		a.eatHumans("Sheila Brovlofsky");
		a.eatHumans();
		a.attackTown();
		a.eatHumans();
		a.fly();
		a.displayEnergy();
	}

}
