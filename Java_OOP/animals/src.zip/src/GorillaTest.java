
public class GorillaTest {
	
	public static void main(String[] args) {
	
		Gorilla a = new Gorilla();
		a.climb();
		a.throwSomething();
		a.eatBanana();
		a.eatBanana();
		a.throwSomething("banana peel");
		a.throwSomething("human remains");
	}
	
}
