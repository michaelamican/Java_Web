
public class Mammal {
	public int energy;
	
	public Mammal(int energy) {
		this.energy = 100;
	}
	
	public void displayEnergy(){
		System.out.println(energy);
	}
	
}
