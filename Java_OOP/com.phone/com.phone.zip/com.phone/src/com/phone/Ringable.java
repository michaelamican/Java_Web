package com.phone;

public interface Ringable {

	String unlock();
	String ring();

}
