public class PuzzleTest{
    public static void main(String[] args){
        Puzzle a = new Puzzle();
        a.posNum();
        a.ninjaName();
        a.allLets();
        a.ranTen();
        a.smallStr();
        a.ranStr();
    }
}