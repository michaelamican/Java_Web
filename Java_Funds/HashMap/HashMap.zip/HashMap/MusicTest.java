import java.util.HashMap;
public class MusicTest{
    public static void main(String[] args){
        Music test = new Music();
        test.compactDisc();
    }
}